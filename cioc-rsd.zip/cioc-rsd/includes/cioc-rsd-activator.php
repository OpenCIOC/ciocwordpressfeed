<?php
class CIOC_RSD_Activator {

	public static function activate() {

	}

}
