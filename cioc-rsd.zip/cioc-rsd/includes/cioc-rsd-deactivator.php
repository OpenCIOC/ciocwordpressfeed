<?php
class CIOC_RSD_Deactivator {
	
	public static function deactivate() {

	}
	
}
