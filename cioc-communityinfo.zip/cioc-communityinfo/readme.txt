=== CIOC Community Information Feeds ===
Contributors: klambacher
Requires at least: 4.0.1
Tested up to: 4.4.1
Stable tag: trunk
License: Apache 2.0
License URI: http://www.apache.org/licenses/LICENSE-2.0

is plugin provides integration shortcodes for feeds from the CIOC Software Volunteer Opportunities module

== Description ==

is plugin provides integration shortcodes for feeds from the CIOC Software Volunteer Opportunities module. For more information visit http://www.opencioc.org

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/cioc-volunteer` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress